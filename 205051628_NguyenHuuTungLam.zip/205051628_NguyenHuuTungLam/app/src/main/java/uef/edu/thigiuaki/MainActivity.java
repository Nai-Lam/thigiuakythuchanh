package uef.edu.thigiuaki;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private ListView dishListView;
    private TextView selectedDishTextView;

    private List<String> dishes;
    private List<Integer> dishImages;
    private List<String> selectedDishes;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dishListView = findViewById(R.id.dishListView);
        selectedDishTextView = findViewById(R.id.selectedDishTextView);

        dishes = Arrays.asList(
                "Bread",
                "Cherry Cheesecake",
                "Gingerbread House",
                "Hamburger",
                "Sunny Side Up Eggs",
                "Beer",
                "Orange Juice",
                "Lemonade",
                "Milk Shake",
                "Coconut Cocktail"
        );

        dishImages = Arrays.asList(
                R.drawable.bread,
                R.drawable.cherrycheesecake,
                R.drawable.gingerbreadhouse,
                R.drawable.hamburger,
                R.drawable.sunnysideupeggs,
                R.drawable.beer,
                R.drawable.orangejuice,
                R.drawable.lemonade,
                R.drawable.milkshake,
                R.drawable.coconutcocktail
        );

        // Reverse the order of dishes starting from index 5
        Collections.reverse(dishes.subList(5, dishes.size()));
        Collections.reverse(dishImages.subList(5, dishImages.size()));

        selectedDishes = new ArrayList<>();

        DishAdapter adapter = new DishAdapter(this, dishes, dishImages);
        dishListView.setAdapter(adapter);

        dishListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String selectedDish = dishes.get(position);
                selectedDishes.add(selectedDish);

                StringBuilder sb = new StringBuilder();
                for (int i = 0; i < selectedDishes.size(); i++) {
                    sb.append("Dish ").append(i + 1).append(": ").append(selectedDishes.get(i));
                    if (i != selectedDishes.size() - 1) {
                        sb.append("\n");
                    }
                }

                selectedDishTextView.setText(sb.toString());
            }
        });
    }
}
